import javax.swing.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.*;
import java.awt.*;

public class GUI extends JFrame {

    int spacing = 5;                           //spacing in between boxes

    public int mouseX;                         //x position of mouse
    public int mouseY;                         //y position of mouse

    int faceX = 325;                           //starting x coordinate of the face
    int faceY = 5;                             //starting y coordinate of the face

    public int topBorder = 26;                 //the top window bar is 26 pixels
    public int edgeBorder = 6;                 //the L&R side of window is 6 pixels

    public int totalMines;                     //number of mines on the board

    public int seconds = 0;                    //variable that stores the elapsed time in seconds

    public int boxNumber;                      //number displayed on each box (# of neighboring mines)

    int [][] mines = new int [9][9];           //2D array returning 0 if mine-free, or 1 if mine-present
    int [][] boxNumberArray = new int [9][9];  //2D array returning number of surrounding mines
    boolean [][] revealed = new boolean[9][9]; //2D array returning true if box is revealed, false if not

    public boolean happyFace = true;           //true if happy face, false if sad face
    public boolean victory = false;            //true if game won
    public boolean defeat = false;             //true if game lost
    public boolean reset = false;              //true if the game is being reset

    Date startDate = new Date();               //date and time are saved the moment the program starts

    //constructor method
    public GUI () {
        this.setTitle("Minesweeper");
        this.setSize (720+edgeBorder,800+topBorder);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);

        this.setVisible(true);

        //method call
        setMines();
        getBoxNumber();

        //create a Board
        Board board = new Board();
        this.setContentPane(board);

        //create Move object and add to program
        Move move = new Move();
        this.addMouseMotionListener(move);

        //create Click object and add to program
        Click click = new Click();
        this.addMouseListener(click);
    }

    //creates board with spaced boxes
    public class Board extends JPanel {
        public void paintComponent(Graphics g) {
            //set background color
            g.setColor(Color.darkGray);
            g.fillRect(0, 0, 720, 800);

            //create 9x9 grid of 80x80 pixel boxes with 10 pixel space between boxes
            for (int i = 0; i < 9; i++) {
                for (int j = 0; j < 9; j++) {
                    int topMenu = 80;
                    int x = spacing + i * 80;
                    int y = spacing + j * 80 + topMenu;
                    int boxDimension = 80 - 2 * spacing;

                    //reveals all of the uncovered mine boxes if user loses
                    if(defeat) {
                        if (mines[i][j] == 1) {
                            revealed[i][j] = true;
                        }
                    }

                    //set box colors
                    g.setColor(Color.gray);
                    if (revealed[i][j]) {
                        g.setColor(Color.white);
                        if (mines[i][j] == 1) {
                            g.setColor(Color.red);
                        }
                    }

                    //changes the color when the mouse hovers over the box
                    if (mouseX >= x && mouseX < x + boxDimension && mouseY >= y + topBorder && mouseY < y + boxDimension + topBorder) {
                        if (revealed[i][j]) {
                            g.setColor(Color.white);
                            if(mines[i][j] == 1) {
                                g.setColor(Color.red);
                            }
                        } else {
                            g.setColor(Color.lightGray);
                        }
                    }

                    g.fillRect(x, y, boxDimension, boxDimension);

                    if (revealed[i][j]) {
                        //updates mine-free box with number of neighboring mines & no number if no neighboring mines
                        if (mines[i][j] == 0 && boxNumberArray[i][j] != 0) {
                            if (boxNumberArray[i][j] == 1) {
                                g.setColor(Color.blue);
                            } else if (boxNumberArray[i][j] == 2) {
                                g.setColor(Color.green);
                            } else if (boxNumberArray[i][j] == 3) {
                                g.setColor(Color.orange);
                            } else if (boxNumberArray[i][j] == 4) {
                                g.setColor(Color.red);
                            } else if (boxNumberArray[i][j] == 5) {
                                g.setColor(Color.magenta);
                            } else if (boxNumberArray[i][j] == 6) {
                                g.setColor(Color.cyan);
                            } else if (boxNumberArray[i][j] == 7) {
                                g.setColor(Color.black);
                            } else if (boxNumberArray[i][j] == 8) {
                                g.setColor(Color.darkGray);
                            }
                            g.setFont(new Font("Calibri", Font.BOLD, 50));
                            g.drawString(Integer.toString(boxNumberArray[i][j]), x+20, y+50);
                        } else if (mines [i][j] == 1) {
                            //show 2D drawing of a mine if the box contains it
                            g.setColor(Color.black);
                            g.fillOval(x+15,y+15,40,40);
                            g.fillRect(x+30,y+10, 10,50);
                            g.fillRect(x+10,y+30,50,10);
                        }
                    }
                }
            }
            //2D drawing of a face
            g.setColor(Color.yellow);
            g.fillOval(faceX,faceY,70,70);
            //eyes of the face
            g.setColor(Color.black);
            g.fillOval(faceX+14,faceY+15,10,20);
            g.fillOval(faceX+44,faceY+15,10,20);
            //mouth of the face
            if (happyFace) {
                //smile
                g.setColor(Color.black);
                g.drawArc(faceX+14,faceY+21,40,40,0,-180);
            } else {
                //frown
                g.setColor(Color.black);
                g.drawArc(faceX+17,faceY+38,35,35,0,180);
            }

            //displays count of total mines
            g.setColor(Color.black);
            g.fillRect(165, spacing, 150,75);

            g.setColor(Color.white);
            g.setFont(new Font ("Dialog", Font.BOLD, 65));
            if (totalMines < 10) {
                g.drawString("0" + Integer.toString(totalMines),200,65);
            } else {
                g.drawString(Integer.toString(totalMines), 200,65);
            }

            //displays the timer
            g.setColor(Color.black);
            g.fillRect(405,spacing,150,75);

            //counts time elapsed in seconds - freezes time if victory or defeat is set to true
            if (!defeat && !victory) {
                seconds = (int) ((new Date().getTime() - startDate.getTime())/1000);
            }
            //set digit limit
            if (seconds > 999) {
                seconds = 999;
            }
            g.setColor(Color.white);
            g.setFont(new Font("Dialog", Font.BOLD, 65));
            if (seconds < 10) {
                g.drawString("00" + Integer.toString(seconds), 425,65);
            } else if (seconds < 100) {
                g.drawString("0" + Integer.toString(seconds), 425,65);
            } else {
                g.drawString(Integer.toString(seconds), 425,65);
            }

            //display win or lose message
            if (defeat) {
                g.setColor(Color.red);
                g.setFont(new Font("Dialog", Font.BOLD, 50));
                g.drawString("You", spacing*2,65);
                g.drawString("Lost!", 585, 65);
            } else if (victory) {
                g.setColor(Color.green);
                g.setFont(new Font("Dialog", Font.BOLD, 50));
                g.drawString("You", spacing*2,65);
                g.drawString("Won!", 585, 65);
            }
        }
    }

    public class Move implements MouseMotionListener {

        @Override
        public void mouseDragged(MouseEvent e) {

        }

        @Override
        public void mouseMoved(MouseEvent e) {
            //returns the coordinates of the mouse
            mouseX = e.getX();
            mouseY = e.getY();
        }
    }

    public class Click implements MouseListener {

        @Override
        public void mouseClicked(MouseEvent e) {
            //returns coordinates of the mouse
            mouseX = e.getX();
            mouseY = e.getY();

            //reveals box if clicked
            if (getBoxCoordinateX() != -1 && getBoxCoordinateY() != -1) {
                revealed[getBoxCoordinateX()][getBoxCoordinateY()] = true;
            }

            //resets the game if the smiley is clicked
            Rectangle rect = new Rectangle(faceX,faceY,70,105);
            if(rect.contains(mouseX,mouseY)) {
                resetGame();
            }
        }

        @Override
        public void mousePressed(MouseEvent e) {

        }

        @Override
        public void mouseReleased(MouseEvent e) {

        }

        @Override
        public void mouseEntered(MouseEvent e) {

        }

        @Override
        public void mouseExited(MouseEvent e) {

        }
    }

    //returns the x position in the 2D array of boxes
    public int getBoxCoordinateX () {
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                int topMenu = 80;
                int x = spacing+i*80;
                int y = spacing+j*80 + topMenu;
                int boxDimension = 80-2*spacing;

                if (mouseX >= x && mouseX < x+boxDimension && mouseY >= y+topBorder && mouseY < y+boxDimension+topBorder) {
                    return i;
                }
            }
        }
        return -1; //means non existent box
    }

    //returns the y position in the 2D array of boxes
    public int getBoxCoordinateY () {
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                int topMenu = 80;
                int x = spacing+i*80;
                int y = spacing+j*80 + topMenu;
                int boxDimension = 80-2*spacing;

                if (mouseY >= y+topBorder && mouseY < y+boxDimension+topBorder && mouseX >= x && mouseX < x+boxDimension) {
                    return j;
                }
            }
        }
        return -1; //means non existent box
    }

    //sets a random placement of mines and returns the number of total mines
    public int setMines () {
        Random random = new Random();

        totalMines = 0;

        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                if (random.nextInt(100) < 16) {
                    mines[i][j] = 1;
                    totalMines++;
                } else {
                    mines[i][j] = 0;
                }
                //sets all boxes to not revealed
                revealed[i][j] = false;
            }
        }
        return totalMines;
    }

    //checks the surrounding boxes for mines and assigns each position with the number of surrounding mines
    public void getBoxNumber () {
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                boxNumber = 0;
                //additional checks to avoid out of bounds
                if (i-1 >= 0 && j-1 >=0 && mines[i-1][j-1] == 1) {
                    boxNumber++;
                }
                if (j-1 >= 0 && mines [i][j-1] == 1) {
                    boxNumber++;
                }
                if (i+1 < 9 && j-1 >= 0 && mines [i+1][j-1] == 1) {
                    boxNumber++;
                }
                if (i+1 < 9 && mines [i+1][j] == 1) {
                    boxNumber++;
                }
                if (i+1 < 9 && j+1 < 9 && mines [i+1][j+1] == 1) {
                    boxNumber++;
                }
                if (j+1 < 9 && mines [i][j+1] == 1) {
                    boxNumber++;
                }
                if (i-1 >= 0 && j+1 < 9 && mines [i-1][j+1] == 1) {
                    boxNumber++;
                }
                if (i-1 >= 0 && mines[i-1][j] == 1) {
                    boxNumber++;
                }

                boxNumberArray[i][j] = boxNumber;
            }
        }
    }

    //resets the game
    public void resetGame () {
        reset = true;

        //reset attributes
        startDate = new Date();
        happyFace = true;
        victory = false;
        defeat = false;

        //reset board
        setMines();
        getBoxNumber();

        reset = false;
    }

    //returns the total number of boxes revealed
    public int getTotalRevealed () {
        int total = 0;
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                if (revealed[i][j]) {
                    total++;
                }
            }
        }
        return total;
    }

    //checks to see if the game is won or lost yet
    public void checkStatus () {
        //defeat
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                if (revealed[i][j] && mines [i][j] == 1) {
                    defeat = true;
                    happyFace = false;
                }
            }
        }
        //win
        if (getTotalRevealed() >= (81 - totalMines)) {
            victory = true;
        }
    }
}

