public class Main implements Runnable {
    GUI gui = new GUI();

    public static void main(String[] args) {
        //when run game, new thread will start
        new Thread(new Main()).start();
    }

    //refreshes game in GUI class
    @Override
    public void run() {
        while(true) {
            gui.repaint();
            if (!gui.reset) {
                gui.checkStatus();
            }
        }
    }
}
 